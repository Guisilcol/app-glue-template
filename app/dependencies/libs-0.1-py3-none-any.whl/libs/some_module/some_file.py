
def some_function():
    print("Hello, World!")