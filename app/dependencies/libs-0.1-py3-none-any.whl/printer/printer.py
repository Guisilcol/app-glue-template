


def print_sucess():
    print('SUCESSO!')